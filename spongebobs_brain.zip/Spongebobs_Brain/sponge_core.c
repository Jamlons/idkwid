#include <stdio.h>
#include <string.h>


void check_password() {
	char input[50];
	printf("Lock password: ");
	scanf("%s", input())

	if (strcmp(input, "Jellyfishing101") == 0) {
		printf("The secret formula is....uhhh.... nothing?");
	} else {
		printf("I hate plankton.");
	}
}

int main() {
	check_password();
	return 0;
}

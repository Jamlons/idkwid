#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/aes.h>

char* base64_decrypt(const char* input, int* length) {
	BIO *bio, *b64;
	int decryptlength = strlen(input) * 3/4;
	char* buffer = (char*)malloc(decryptlength+1);

	bio = BIO_new_mem_buf(input, -1);
	b64 = BIO_new(BIO_f_base64());
	bio = BIO_push(b64, bio);

	BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
	*length = BIO_read(bio, buffer, strlen(input));
	buffer[*length] = '\0';

	BIO_free_all(bio);

	return buffer;
}

void check(const char* typed_password) {
	const char* local8 = "YnViYmxlcw==";
	const char* local101 = "6157527264326c6b4f6945324f554a58595668414957465549513d3d";
	int count =0;

	char* decoded_password = base64_decrypt(local8, &count);

	if (strcmp(typed_password, decoded_password) == 0) {
		printf("50 percent Minced planktons with one tea spoon of opium and one clove of garlic and onions with one beaten egg and some cornstarch\n" );
	} else {
		printf("Sucks to be you Plankton!\n");
	}

	free(decoded_password);
}

int main() {
	char password[100];

	printf("Enter the secret words: ");
	scanf("%99s", password);
	
	check(password);

	return 0;
}
			

